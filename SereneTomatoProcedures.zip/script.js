/* 
youtube univers - man starter som en youtuber, og kæmper til sidst mod Ben Shapiro
Sidste boss er T-Series / PewDiePie
hater man på Logan / Jake, dapper han i reflect og man dør.
*/

alert("Alle svar skal være med stort forbogstav.");

// Rum 1
// Function1 spørger om du er klar til at spille.
function f1() {
  var p1 = prompt("Er du klar til at spille?");
  parseInt(p1)

  // Udskriver tekst hvis svaret er ja.
  if(p1 == "Ja") {
    console.log("Du er i dit hus. Huset ligger ude midt på landet. Der er mindst 15km til nærmeste by, og hvis du skal derind skal du gå. Du har nemlig ingen bil, cykel eller knallert etc.");
    

  }
  // Restarter hvis svaret er nej, som tvinger spilleren til at skrive ja.
  if(p1 == "Nej"){
    setTimeout(f1(), 1000);
  }

}
f1();
// Rum 2
function f2(){

}


// Rum 3
function f3() {


}



// Rum 4
function f4() {


}



// Rum 5
function f5() {


}



// Rum 6
// Du møder jp her.
function f6() {
console.log ("Du befinder dig i en skov, der er træer så langt øjet rækker")

}



// Rum 7
function f7() {


}


// Rum 8
function f8() {


}



// Rum 9
function f9() {


}


// Rum 10
function f10() {


}
